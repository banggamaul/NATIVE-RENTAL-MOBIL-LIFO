-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2025 at 02:08 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_lifo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(50) CHARACTER SET latin1 NOT NULL,
  `ktp` varchar(17) NOT NULL,
  `jk_admin` varchar(30) CHARACTER SET latin1 NOT NULL,
  `alamat` varchar(90) NOT NULL,
  `no_tlp` varchar(14) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 NOT NULL,
  `level` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `ktp`, `jk_admin`, `alamat`, `no_tlp`, `username`, `password`, `level`) VALUES
(1, 'andi', '', 'laki-laki', '', '', 'andi', 'andi123', 'Super'),
(4, 'budi', '', 'Laki-Laki', '', '', 'budi', '123', 'Admin'),
(12, 'putra', '1234567890123456', 'Laki-Laki', 'surabaya', '081234567890', 'putra', '123', 'Pelanggan'),
(14, 'putri', '1234567890123456', 'Laki-Laki', 'surabaya', '081234567890', 'putri', '123', 'Pelanggan'),
(17, 'agus', '1234567890123456', 'Laki-Laki', 'sidoarjo', '081234567890', 'agus', '123', 'Pelanggan'),
(18, 'adi', '1234567890123456', 'Laki-Laki', 'gresik', '081234567890', 'adi', '123', 'Pelanggan'),
(21, 'iksan', '1234567890123456', 'Laki-Laki', 'surabaya', '081234567890', 'kucur', '123', 'Pelanggan'),
(22, 'Andy Wildan', '', 'Laki-Laki', '', '', 'wildan', '123', 'Admin'),
(23, 'anthony ', '', 'Laki-Laki', '', '', 'tony ', '123', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `id_mobil` int(11) NOT NULL,
  `no_polisi` varchar(15) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `tahun` varchar(10) NOT NULL,
  `harga` double NOT NULL,
  `s_mobil` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `no_polisi`, `merk`, `tahun`, `harga`, `s_mobil`, `created_at`, `last_updated`) VALUES
(7, 'B4312AB', 'Avanza', '2024', 450000, 'Ready', '2025-10-27 02:29:42', '2025-11-04 20:35:39'),
(8, 'L2222SS', 'Avanza', '2022', 450000, 'Ready', '2025-10-27 02:27:05', '2025-11-17 09:18:20'),
(9, 'L1111AA', 'innova', '2022', 600000, 'Ready', '2025-10-27 02:27:05', '2025-11-04 13:47:21'),
(10, 'L2222BB', 'Innova', '2024', 600000, 'Ready', '2025-10-27 02:27:05', '2025-11-04 20:37:02'),
(14, 'L3333CC', 'Ayla', '2024', 500000, 'Di sewa', '2025-10-27 02:27:05', '2025-11-04 20:30:07'),
(15, 'L4331AA', 'Avanza', '2023', 450000, 'Ready', '2025-10-27 02:27:05', '2025-10-27 13:16:58'),
(16, 'L7777QW', 'Ayla', '2024', 350000, 'Maintenance', '2025-11-02 09:44:03', '2025-11-17 09:19:01');

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE `sewa` (
  `id_sewa` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `nama_order` varchar(90) NOT NULL,
  `ktp` varchar(17) NOT NULL,
  `jk_order` varchar(20) NOT NULL,
  `alamat` varchar(90) NOT NULL,
  `tlp_order` varchar(14) NOT NULL,
  `tujuan` varchar(90) NOT NULL,
  `tgl_order` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `lama` int(11) NOT NULL,
  `harga_total` double NOT NULL,
  `s_order` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sewa`
--

INSERT INTO `sewa` (`id_sewa`, `id_mobil`, `id_admin`, `nama_order`, `ktp`, `jk_order`, `alamat`, `tlp_order`, `tujuan`, `tgl_order`, `tgl_kembali`, `lama`, `harga_total`, `s_order`) VALUES
(19, 8, 12, 'putra', '1234567890123456', 'Laki-Laki', 'surabaya', '081234567890', 'malang', '2025-11-04', '2025-11-11', 7, 3150000, 'DiKembalikan'),
(22, 8, 17, 'agus', '1234567890123456', 'Laki-Laki', 'sidoarjo', '081234567890', 'jombang', '2025-11-05', '2025-11-14', 9, 4050000, 'DiKembalikan'),
(23, 14, 21, 'iksan', '1234567890123456', 'Laki-Laki', 'surabaya', '081234567890', 'surabaya', '2025-11-17', '2025-11-18', 1, 500000, 'Di Sewa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id_mobil`);

--
-- Indexes for table `sewa`
--
ALTER TABLE `sewa`
  ADD PRIMARY KEY (`id_sewa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id_mobil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sewa`
--
ALTER TABLE `sewa`
  MODIFY `id_sewa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
